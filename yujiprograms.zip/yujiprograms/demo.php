<?php 

echo "First PHP Program";

?>