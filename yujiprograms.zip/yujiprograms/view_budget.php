<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Budgets</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        /* General styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            color: #333;
        }
        
        h2 {
            color: #333;
            margin: 20px 0;
        }

        /* Table styling */
        table {
            width: 80%;
            max-width: 800px;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #0066cc;
            color: #ffffff;
            font-weight: bold;
            cursor: pointer;
        }

        th:hover {
            background-color: #004999;
        }

        td {
            color: #555;
        }

        /* Search bar styling */
        .search-container {
            margin: 20px auto;
            width: 80%;
            max-width: 800px;
            text-align: center;
        }

        .search-container input[type="text"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination button {
            padding: 8px 12px;
            margin: 0 5px;
            border: none;
            border-radius: 5px;
            background-color: #0066cc;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .pagination button:hover {
            background-color: #004999;
        }

        .pagination button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        /* Back button */
        .back-button {
            margin-top: 20px;
            text-align: center;
        }

        .back-button button {
            padding: 10px 20px;
            font-size: 1em;
            color: white;
            background-color: #0066cc;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .back-button button:hover {
            background-color: #004999;
        }
    </style>
</head>
<body>
    <h2>All Budgets</h2>

    <div class="search-container">
    <input type="text" id="searchBar" placeholder="Search by Purpose..." onkeyup="searchTable()">
</div>

<?php
session_start();
include "db_conn.php";

if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id']; // Ensure this matches your session variable

    // Fetch budgets for the logged-in user
    $result = $conn->query("SELECT * FROM budgets WHERE user_id = $user_id");

    if ($result && mysqli_num_rows($result) > 0) {
        echo "<table id='budgetTable'>";
        echo "<thead><tr><th onclick='sortTable(0)'>Purpose</th><th onclick='sortTable(1)'>Total Amount (PHP)</th><th onclick='sortTable(2)'>Remaining Amount (PHP)</th></tr></thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_assoc($result)) {
            $purpose = htmlspecialchars($row['Purpose']);
            $total_amount = number_format($row['total_amount'], 2);
            $remaining_amount = number_format($row['remaining_amount'], 2);
            echo "<tr>";
            echo "<td>$purpose</td>";
            echo "<td>PHP $total_amount</td>";
            echo "<td>PHP $remaining_amount</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p class='no-data'>No budgets available.</p>";
    }
} else {
    header("Location: index.php");
    exit();
}
?>

<div class="back-button">
    <button onclick="window.location.href='home.php'">Back to Home</button>
</div>

<script>
function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchBar");
    filter = input.value.toUpperCase();
    table = document.getElementById("budgetTable");
    tr = table.getElementsByTagName("tr");

    for (i = 1; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }       
    }
}

function sortTable(n) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById("budgetTable");
    switching = true;
    dir = "asc"; 
    while (switching) {
        switching = false;
        rows = table.rows;
        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[n];
            y = rows[i + 1].getElementsByTagName("TD")[n];
            if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchcount ++;      
        } else {
            if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}

</script>
</body>
</html>
