<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #1e40af;
            --background-color: #f8fafc;
            --card-background: #ffffff;
            --text-primary: #1f2937;
            --text-secondary: #4b5563;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--background-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-primary);
        }

        .budget-container {
            background: var(--card-background);
            max-width: 500px;
            width: 90%;
            padding: 3rem;
            border-radius: 1.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .submit-button,
        .back-button {
            padding: 0.50rem;
            border-radius: 0.3rem;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1rem; /* Add some margin to improve spacing */
        }

        .submit-button {
            background: var(--primary-color);
            color: white;
        }

        .submit-button:hover {
            background: var(--secondary-color);
        }

        .back-button {
            background: #e5e7eb;
            color: var(--text-primary);
            border: 1px solid #d1d5db;
        }

        .back-button:hover {
            background: #d1d5db;
        }

        .message.error {
            background: #fee2e2;
            color: #dc2626;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid #dc2626;
        }

        .message.success {
            background: #dcfce7;
            color: #16a34a;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid #16a34a;
            font-weight: bold;
        }

        .form-control {
            display: flex;
            flex-direction: column;
            margin-bottom: 1.5rem;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-secondary);
        }

        .form-input {
            padding: 0.5rem;
            border-radius: 0.375rem;
            border: 1px solid #d1d5db;
            transition: border-color 0.2s ease;
        }

        .form-input:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        .form-input::placeholder {
            color: #9ca3af;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 1.5rem;
        }
    </style>
</head>

<body>
    <div class="budget-container">
        <h2 class="text-3xl font-bold mb-6 text-center">Budget Management</h2>
        <div id="message" class="message" style="display:none;"></div>
        <form id="deductForm" class="space-y-4">
            <div class="form-control">
                <label for="budget_id" class="form-label">Select Budget Category</label>
                <select name="budget_id" id="budget_id" class="form-input" required>
                    <option value="">Choose a budget category</option>
                    <?php 
                    session_start();
                    include "db_conn.php";
                    if (isset($_SESSION['id'])) {
                        $user_id = $_SESSION['id']; // Ensure this matches your session variable
                        $result = $conn->query("SELECT id, Purpose, remaining_amount FROM budgets WHERE user_id = $user_id");
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['id']}'>{$row['Purpose']} - ₱" . 
                                 number_format($row['remaining_amount'], 2) . "</option>";
                        }
                    } else {
                        header("Location: index.php");
                        exit();
                    }
                    ?>
                </select>
            </div>
            <div class="form-control">
                <label for="amount" class="form-label">Deduction Amount (₱)</label>
                <input type="number" name="amount" id="amount" class="form-input" step="0.01" min="0" placeholder="Enter amount" required>
            </div>
            <div class="button-container">
                <button type="submit" class="submit-button w-full">Process Deduction</button>
                <a href="home.php" class="back-button">Back to Main Menu</a>
            </div>
        </form>
    </div>
    <script>
        document.getElementById('deductForm').addEventListener('submit', async function (e) {
            e.preventDefault();
            const submitButton = this.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.innerHTML = 'Processing...';
            const messageDiv = document.getElementById('message');
            messageDiv.className = ''; // Reset any existing message class
            messageDiv.innerHTML = ''; // Clear previous messages
            try {
                const formData = new FormData(this);
                const response = await fetch('deduct_budget_process.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                messageDiv.className = data.status === 'success' ? 'message success' : 'message error';
                messageDiv.innerHTML = data.message;
                messageDiv.style.display = 'block';
                if (data.status === 'success') {
                    setTimeout(() => location.reload(), 1500);
                }
            } catch (error) {
                messageDiv.className = 'message error';
                messageDiv.innerHTML = 'An unexpected error occurred. Please try again.';
                messageDiv.style.display = 'block';
            } finally {
                submitButton.disabled = false;
                submitButton.innerHTML = 'Process Deduction';
            }
        });
    </script>
</body>

</html>