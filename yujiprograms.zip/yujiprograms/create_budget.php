<!DOCTYPE html>
<html lang="en">
<head>
 
    
    <title>Create Budget</title>
    <link rel ="stylesheet" type="text/css" href="style.css">
</head>
<body>
   
    <h2>Create a New Budget</h2>
    <form action="create_budget_check.php" method="POST">
        <label for="purpose">Purpose:</label>
        <input type="text" name="purpose" required><br><br>
        
        <label for="amount">Initial Amount (PHP):</label>
        <input type="number" name="amount" required><br><br>
        
        <button type="submit">Create Budget</button>
   
    <a href="home.php" class="btm">Back to Main Menu</a>
    </form>
</body>
</html>